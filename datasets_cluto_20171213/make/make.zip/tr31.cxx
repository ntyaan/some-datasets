#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "301", "306", "307",
      "304", "305", "302" ,"310"
    };
  f(7, 927, strList, "tr31");
  return 0;
}

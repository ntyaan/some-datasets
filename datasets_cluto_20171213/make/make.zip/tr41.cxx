#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "352","357","351","354","359",
      "360","358","355","353","356"
    };
  f(10, 878, strList, "tr41");
  return 0;
}

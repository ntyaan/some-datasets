#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "DNA","Carcinoma","Tomography",
      "In-Vitro","Antibodies","Risk-Factors",
      "Prognosis","Receptors","Pregnancy",
      "Molecular-Sequence-Data"
    };
  f(10, 11162, strList, "ohscal");
  return 0;
}

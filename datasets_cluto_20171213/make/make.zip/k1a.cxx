#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "H","Ep","Ec","Em","Ei","Ef","Emu",
      "Et","Ev","Ea","Er","Es","Ecu",
      "Eo","E","Emm","S","P","T","B"
    };
  f(20, 2340, strList, "k1a");
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "People", "Television", "Health",
      "Media", "Art" ,"Film",
      "Business", "Cable", "Culture",
      "Politics" , "Sports", "Review",
      "Music", "Technology", "Entertainment",
      "Online", "Industry", "Stage",
      "Variety", "Multimedia"
    };
  f(20, 1560, strList, "wap");
  return 0;
}

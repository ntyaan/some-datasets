#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "health", "entertainment", "sports",
      "politics", "tech" ,"business"
    };
  f(6, 2340, strList, "k1b");
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "computer","electronics","medical"
      ,"health","research","technology"
    };
  f(6, 2301, strList, "hitech");
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "housing", "money", "trade",
      "reserves", "cpi" ,"interest",
      "gnp", "retail", "ipi", "jobs",
      "lei",  "bop", "wpi"
    };
  f(13, 1504, strList, "re0");
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "Financial","Foreign","National",
      "Metro","Sports","Entertainment"
    };
  f(6, 3204, strList, "la1");
  return 0;
}

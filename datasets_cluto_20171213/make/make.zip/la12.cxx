#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "Financial","Foreign","National",
      "Metro","Sports","Entertainment"
    };
  f(6, 6279, strList, "la12");
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "cran","med"
    };
  f(2, 2431, strList, "cranmed");
  return 0;
}

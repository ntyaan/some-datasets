#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "78", "54", "82", "58",
      "100", "95", "94", "77",
    };
  f(8, 313, strList, "tr12");
  return 0;
}

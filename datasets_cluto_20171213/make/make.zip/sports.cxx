#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "baseball","basketball","football",
      "hockey","boxing", "bicycle", "golf"
    };
  f(7, 8580, strList, "sports");
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "food","movie","music",
      "radio","restaurant"
    };
  f(5, 4069, strList, "reviews");
  return 0;
}

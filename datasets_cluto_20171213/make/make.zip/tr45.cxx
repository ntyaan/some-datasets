#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "400", "399", "392",
      "391", "395", "397",
      "393", "394", "398",
      "396"
    };
  f(10, 690, strList, "tr45");
  return 0;
}

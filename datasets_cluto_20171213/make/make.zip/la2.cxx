#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "Financial","Foreign","National",
      "Metro","Sports","Entertainment"
    };
  f(6, 3075, strList, "la2");
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "274", "273", "277",
      "271", "280", "272"
    };
  f(6, 204, strList, "tr23");
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "cacm","cisi"
    };
  f(2, 4663, strList, "cacmcisi");
  return 0;
}

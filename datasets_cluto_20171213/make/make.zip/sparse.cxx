#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#define REP(i,n) for(int i=(0);i<(n);i++)
int main(const int argc, const char *argv[]){
  (void)argc;
  std::string argv0=argv[1];
  std::string argv1=argv[2];
  int row,col,size;
  std::ifstream ifs1(argv0+".mat");
  if(ifs1.fail()){std::cerr<<"argv0 error\n";exit(1);}
  std::ifstream ifs2(argv1);
  if(ifs2.fail()){std::cerr<<"argv1 error\n";exit(1);}
  ifs1>>row>>col>>size;
  std::vector< std::vector<double> > A;
  A.resize(row);
  REP(i,row)
    A[i].resize(col);
  REP(i,row){
    REP(j,col){
      A[i][j]=0.0;
    }
  }
  int col_index,row_index=0;
  int max_col_index=0;
  double value;
  REP(i,row){
    ifs2>>size;
    REP(i,size){
      ifs1>>col_index>>value;
      A[row_index][col_index-1]=value;
      if(col_index>max_col_index)
	max_col_index=col_index;
    }
    row_index++;
  }
  ifs1.close();
  ifs2.close();
  std::vector<int> B;
  B.resize(row_index);
  std::ofstream ofs("CLUTO/"+argv0+"/sparse_"+argv0+".txt");
  ofs<<row_index<<" "<<max_col_index<<"\n";
  REP(i,row_index){
    B[i]=0;
    REP(j,max_col_index){
      if(A[i][j]>0.0){
	B[i]++;
      }
    }
    ofs<<B[i]<<" ";
    REP(j,max_col_index){
      if(A[i][j]>0.0)
	ofs<<j<<" "<<A[i][j]<<" ";
    }
    ofs<<std::endl;
  }
  return 0;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "cran","med","cacm","cisi"
    };
  f(4, 7094, strList, "classic");
  return 0;
}

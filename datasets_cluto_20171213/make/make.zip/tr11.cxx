#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "4", "12", "3", "1",
      "24", "5", "6", "44",
      "11"
    };
  f(9, 414, strList, "tr11");
  return 0;
}

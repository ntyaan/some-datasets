#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "cocoa","grain","veg","wheat",
      "copper","coffee","sugar",
      "ship","cotton","carcass",
      "crude","nat","meal","alum",
      "oilseed","gold","tin",
      "livestock","iron","rubber","tin",
      "zinc","gas","orange","dlr"
    };
  f(25, 1657, strList, "re1");
  return 0;
}

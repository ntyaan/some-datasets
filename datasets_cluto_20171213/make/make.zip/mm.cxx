#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "movie", "music", 
    };
  f(2, 2521, strList, "mm");
  return 0;
}

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#define REP(i,n) for(int i=(0);i<(n);i++)
void f(int argv1, int argv2
       , std::vector<std::string> &strList, std::string file){
  std::string str;
  std::ofstream ofs("CLUTO/"+file+"/"+file+"_correct.txt");
  REP(i,argv1){
    std::ifstream ifs(file+".mat.rclass");
    if(!ifs)exit(1);
    REP(k,argv2){
      ifs>>str;
      if(str==strList[i])
	ofs<<1<<" ";
      else
	ofs<<0<<" ";
    }
    ofs<<std::endl;
    ifs.close();
  }
  ofs.close();
  std::ifstream ifs("CLUTO/"+file+"/"+file+"_correct.txt");
  int x=0,sum=0;;
  REP(i,argv1){
    REP(j,argv2){
      ifs>>x;
      sum+=x;
    }
  }
  std::cout<<"data number:"<<sum<<std::endl;
  return;
}

#include "func.h"
int main(){
  std::vector<std::string> strList=
    {
      "202", "187", "189", "100", "108", "142" ,"118",
      "161", "111", "221", "3", "11", "95", "240",
      "4", "12", "119"
    };
  f(17, 2463, strList, "fbis");
  return 0;
}
